<?php
/**
 * If you use the plugins outside the wp-root or other one install, 
 * then you must define the absolute path to wp-load.php in the install root of WordPress
 * 
 * Examples:
 * Linux: $wp_siteurl = '/var/www/wpbeta';
 * Windows client with XAMPP: $wp_siteurl = 'C:/xampp/htdocs/wpbeta';
 */

// the path to wp-load.php