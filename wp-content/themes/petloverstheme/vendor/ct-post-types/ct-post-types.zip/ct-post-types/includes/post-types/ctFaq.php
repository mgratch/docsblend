<?php

if (!class_exists('ctFaqType')) {

    //require_once CT_THEME_LIB_DIR . '/types/ctFaqTypeBase.class.php';

    /**
     * Custom type - faq
     */
    class ctFaqType extends ctFaqTypeBase
    {
    }


    new ctFaqType();

}