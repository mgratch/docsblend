(function ( $ ) {
    "use strict";
    $(function () {
        $('#ct-waitlist-usewoocommercefrom').on('click', function () {
            $('.tr1').slideToggle("fast","linear");
            $('.tr2').slideToggle("fast","linear");

        });
        $('#ct-waitlist-usewootemplate').on('click', function () {
            $('.tr3').slideToggle("fast","linear");
        });
        $('#ct-waitlist-sendsubscriptionsuccessmessage').on('click', function () {
            $('.tr4').slideToggle("fast","linear");
            $('.tr5').slideToggle("fast","linear");

        });
        $('#ctWaitlist_use_custom_css').on('click', function(){
            $('.tr6').slideToggle("fast","linear");
        });
        $('#ctWaitlist_admin_notifications').on('click', function () {
            $('.tr7').slideToggle("fast","linear");
            $('.tr8').slideToggle("fast","linear");

        });
        $('#ctWaitlist_admin_send_on_buy').on('click', function () {
            $('.tr9').slideToggle("fast","linear");
            $('.tr10').slideToggle("fast","linear");

        });
        $('#ctWaitlist_admin_send_on_notify').on('click', function () {
            $('.tr11').slideToggle("fast","linear");
            $('.tr12').slideToggle("fast","linear");

        });




    });

    $(window).on('load', function(){


        jQuery.each($('.forDisableGroup'), function(){
            var $toggle = $(this).find('.toggleable');
            var $table = $(this).find('table');

            console.log($toggle);

            $toggle.on('click', function(e){
                e.preventDefault();
                $table.slideToggle("fast","linear");
            })
        })

    })
}(jQuery));
