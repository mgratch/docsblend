<?php
$optionTable = 'ctWaitlist_options';
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) )
    exit;

if(get_option($optionTable['ctWaitlist_remove_data_on_delete']) != 'on') {
    wp_die();
} else {
    delete_option('ctWaitlist_options');

}

?>